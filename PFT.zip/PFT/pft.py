import tkinter as tk
from tkinter import simpledialog
from tkinter import ttk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

window = tk.Tk()
window.title("Personal Finance Tracker")
window.geometry("1200x600")
window.resizable(False, False)

text_title = tk.Label(window,text="PFT (Personal Finance Tracker)",font=("Helvetica",20))
text_title.grid(row=1,column=0,pady=(0,5))
  
#Money Counter
l_counter = tk.Label(window,text="Your money ($): ",font=("Helvetica",20))
l_counter.grid(row=5,column=0)
counter = 0
mov = 30
canvas = None
text_counter = tk.Label(window,text=counter,font=("Helvetica",20))
text_counter.grid(row=5,column=1,pady=(0,10))

#Add money to the counter section
"""text_ladd = tk.Label(window,text="Insert the amount of money to add ($):")
text_ladd.grid(row=10,column=0,pady=(0,5))


text_add = tk.Entry()
text_add.grid(row=15,column=0,pady=(0,5))"""

cat_list = {}

def add_money():
    window.withdraw()
    causale = simpledialog.askstring("Causale","Insert the causal of the movement:")
    global counter
    add = simpledialog.askinteger("Add","Insert the amount of money to add:")
    counter += int(add)
    text_counter.config(text=counter)
    window.deiconify()
    new_movement = tk.Label(movements_frame, text=f"(Income) {causale} → +{add} $")
    new_movement.pack(anchor="w")

#Remove money to the counter section
"""text_lremove = tk.Label(window,text="Insert the amount of money to remove ($):")
text_lremove.grid(row=25,column=0,pady=(0,5))

text_remove = tk.Entry()
text_remove.grid(row=30,column=0,pady=(0,5))"""

def remove_money():
    window.withdraw()
    category = simpledialog.askstring("Category","Insert the category of the movement (if none write 'other')")
    if category not in cat_list:
        cat_list[category] = 0
    causale = simpledialog.askstring("Causale","Insert the causal of the movement:")
    global counter
    remove = simpledialog.askinteger("Remove","Insert the amount of money to remove:")
    counter -= int(remove)
    text_counter.config(text=counter)
    cat_list[category] += remove
    window.deiconify()
    new_movement = tk.Label(movements_frame, text=f"(Payment) {causale} → -{remove} $")
    new_movement.pack(anchor="w")

button_add = tk.Button(text="NEW ENTRY",command=add_money)
button_add.grid(row=10,column=0,pady=(0,5))

button_remove = tk.Button(text="NEW EXIT",command=remove_money)
button_remove.grid(row=15,column=0,pady=(0,10))

graph_frame = tk.Frame(window, width=600, height=400)
graph_frame.grid(row=1, column=3, rowspan=30, padx=20)

movements_container = tk.Frame(window)
movements_container.grid(row=25, column=0, rowspan=20, padx=20, pady=10, sticky="n")

canvas_mov = tk.Canvas(
    movements_container,
    width=350,
    height=250,
    highlightthickness=0
)
canvas_mov.pack(side="left", fill="both", expand=False)

scrollbar = ttk.Scrollbar(
    movements_container,
    orient="vertical",
    command=canvas_mov.yview
)
scrollbar.pack(side="right", fill="y")

canvas_mov.configure(yscrollcommand=scrollbar.set)

movements_frame = tk.Frame(canvas_mov)

canvas_frame = canvas_mov.create_window(
    (0, 0),
    window=movements_frame,
    anchor="nw"
)

def update_scroll(event=None):
    canvas_mov.configure(scrollregion=canvas_mov.bbox("all"))

movements_frame.bind("<Configure>", update_scroll)

def create_pie_graph():
    global canvas 
    if canvas:
        canvas.get_tk_widget().destroy()

    labels = cat_list.keys()
    values = cat_list.values()
    
    fig = Figure(figsize=(4,4),dpi=100)
    ax = fig.add_subplot(111)

    ax.pie(values,labels=labels,autopct='%1.1f%%')
    ax.set_title("Outcome distribution")

    canvas = FigureCanvasTkAgg(fig, master=graph_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

b_graph = tk.Button(window,text="PIE GRAPH",command=create_pie_graph)
b_graph.grid(row=2,column=2,padx=5)

window.mainloop()