import tkinter as tk
from tkinter import simpledialog

window = tk.Tk()
window.title("Personal Finance Tracker")
window.geometry("1200x600")
window.resizable(False, False)

text_title = tk.Label(window,text="PFT (Personal Finance Tracker)",font=("Helvetica",20))
text_title.grid(row=1,column=0,pady=(0,5))
  
#Money Counter
l_counter = tk.Label(window,text="Your money ($): ",font=("Helvetica",20))
l_counter.grid(row=5,column=0)
counter = 0
mov = 30
text_counter = tk.Label(window,text=counter,font=("Helvetica",20))
text_counter.grid(row=5,column=1,pady=(0,10))

#Add money to the counter section
"""text_ladd = tk.Label(window,text="Insert the amount of money to add ($):")
text_ladd.grid(row=10,column=0,pady=(0,5))


text_add = tk.Entry()
text_add.grid(row=15,column=0,pady=(0,5))"""

def add_money():
    window.withdraw()
    causale = simpledialog.askstring("Causale","Insert the causal of the movement:")
    global counter
    add = simpledialog.askinteger("Add","Insert the amount of money to add:")
    counter += int(add)
    text_counter.config(text=counter)
    window.deiconify()
    new_movement = tk.Label(window,text=causale+" --> Amount: "+str(add)+" $")
    global mov
    new_movement.grid(row=mov,column=0,pady=(0,5))
    mov = mov + 5

#Remove money to the counter section
"""text_lremove = tk.Label(window,text="Insert the amount of money to remove ($):")
text_lremove.grid(row=25,column=0,pady=(0,5))

text_remove = tk.Entry()
text_remove.grid(row=30,column=0,pady=(0,5))"""

def remove_money():
    window.withdraw()
    causale = simpledialog.askstring("Causale","Insert the causal of the movement:")
    global counter
    remove = simpledialog.askinteger("Remove","Insert the amount of money to remove:")
    counter -= int(remove)
    text_counter.config(text=counter)
    window.deiconify()
    new_movement = tk.Label(window,text=causale+" --> Amount: -"+str(remove)+" $")
    global mov
    new_movement.grid(row=mov,column=0,pady=(0,5))
    mov = mov + 5

button_add = tk.Button(text="NEW ENTRY",command=add_money)
button_add.grid(row=10,column=0,pady=(0,5))

button_remove = tk.Button(text="NEW EXIT",command=remove_money)
button_remove.grid(row=15,column=0,pady=(0,10))

l_movement = tk.Label(window,text="LIST OF MOVEMENTS: ",font=("Helvetica",20))
l_movement.grid(row=25,column=0,pady=(0,5))


window.mainloop()