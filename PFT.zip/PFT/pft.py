import tkinter as tk

window = tk.Tk()
window.title("Personal Finance Tracker")
window.geometry("1200x600")
window.resizable(False, False)

text_title = tk.Label(window,text="PFT (Personal Finance Tracker)",font=("Helvetica",20))
text_title.grid(row=1,column=0,pady=(0,5))
  
#Money Counter
l_counter = tk.Label(window,text="Your money ($): ")
l_counter.grid(row=5,column=0)
counter = 0
text_counter = tk.Label(window,text=counter)
text_counter.grid(row=5,column=1,pady=(0,10))

#Add money to the counter section
text_ladd = tk.Label(window,text="Insert the amount of money to add ($):")
text_ladd.grid(row=10,column=0,pady=(0,5))

text_add = tk.Entry()
text_add.grid(row=15,column=0,pady=(0,5))

def update_status():
    global counter
    counter += int(text_add.get())
    text_counter.config(text=counter)

button_add = tk.Button(text="ADD",command=update_status)
button_add.grid(row=20,column=0)



window.mainloop()